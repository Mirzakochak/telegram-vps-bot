#!/bin/bash

echo "🔧 VPS Telegram Bot Installer via GitHub"

read -p "Enter your Telegram Bot Token: " TOKEN
read -p "Enter MySQL Database Name: " DBNAME
read -p "Enter MySQL Username: " DBUSER
read -s -p "Enter MySQL Password: " DBPASS
echo
read -p "Enter your domain (e.g. example.com): " DOMAIN
read -p "Enter your NextPay API Key: " NEXTKEY

sudo apt update
sudo apt install -y apache2 php php-mysqli php-curl unzip curl

cd /tmp
curl -LO https://github.com/YOUR_USERNAME/YOUR_REPO/archive/refs/heads/main.zip
unzip main.zip
sudo cp -r YOUR_REPO-main/telegram-bot-files/* /var/www/html/bot/

# ویرایش فایل‌ها و تنظیم Webhook و Cron مشابه نسخه قبلی
# ...

echo "✅ نصب کامل شد! ربات در https://${DOMAIN}/bot آماده است."
